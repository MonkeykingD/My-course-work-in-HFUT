//*********************************************************
//File name	 : 0422
//Author  	 : ������ 
//Date   	 : 2019.11.20
//Student ID   :2019218043
//*********************************************************

#include<stdio.h>
#include<stdlib.h>
int main()
{
	int a[3][3], b[3][3], c[3][3];
	int i = 0, j = 0, k = 0;
	int sum = 0;

	printf("�����һ�����׾���\n");
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			scanf_s("%d", &a[i][j]);
		}
	}
	printf("����ڶ������׾���\n");
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			scanf_s("%d", &b[i][j]);
		}
	}

	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			sum = 0;
			for (k = 0; k < 3; k++)
			{
				sum = sum + a[i][k] * b[k][j];
			}
			c[i][j] = sum;
		}
	}

	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			printf("%-4d", c[i][j]);
		}
		printf("\n");
	}
	system("pause");

	return 0;
}