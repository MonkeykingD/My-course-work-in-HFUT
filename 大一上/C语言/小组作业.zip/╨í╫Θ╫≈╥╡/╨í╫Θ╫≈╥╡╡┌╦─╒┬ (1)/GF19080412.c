//*********************************************************
//File name	 :GF19080412
//Author  	 :�����
//Date   	 :11��20��
//Student ID   :2019218029
//*********************************************************
#include<stdio.h>
int main(void)
{
    int a[20], b[20], i, x, j;
    j = 0;
    printf("������ѧ�źͷ���:\n");
    for(i = 0; i < 20; i++)
    {
        scanf("%d",&a[i]);
        scanf("%d",&b[i]);
    }
    printf("������Ҫ���ҵķ���:");
    scanf("%d",&x);
    for(i = 0; i < 20; i++)
    {
        if(x == b[i])
        {
            printf("ѧ��Ϊ:%d",a[i]);
            break;
        }
        j++;
    }
    if(j == 20)
    {
        printf("δ�ҵ�!");
    }
    return 0;
}
