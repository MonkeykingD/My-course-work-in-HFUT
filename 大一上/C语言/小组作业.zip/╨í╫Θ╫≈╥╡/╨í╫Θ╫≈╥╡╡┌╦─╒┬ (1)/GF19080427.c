//*********************************************************
//File name	 :GF19080427 
//Author  	 :����ƽ  
//Date   	 :11��17�� 
//Student ID   :2019218018 
//*********************************************************
#include <stdio.h>
#include <stdlib.h>

int main()
{
	srand(time(0));
	int a[20],i,j,k,t,x,low,max,mid;
	
	printf("������Ҫ���ҵ���:\n");
	
	for(i=0;i<20;i++)
		a[i]=rand();
	scanf("%d",&x);	
	
	for(i=0;i<19;i++)
	{
		k=i;
		for(j=i+1;j<20;j++)
			if(a[j]>a[i])
				i=j;		
		if(i!=k)
		{
			t=a[i];
			a[i]=a[k];
			a[k]=t;
		}
		i=k;			
	}
	for(i=0;i<20;i++)
		printf("%d ",a[i]);
	printf("\n");
		
	low=0;
	max=19;
	while(low<=max)
	{
		mid=(low+max)/2;
		if(x==a[mid])
		{
			printf("���ҵ���!");
			break;
		}
		else if(x>a[mid])
			low=mid+1;
		else
			max=mid-1;		
	}
	if(low>max)
		printf("û�ҵ�!");
				
	return 0;	
		
 } 
