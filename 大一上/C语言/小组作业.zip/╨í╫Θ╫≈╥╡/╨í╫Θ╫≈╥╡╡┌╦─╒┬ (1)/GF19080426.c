//*********************************************************
//File name	 :0601
//Author  	 :�����
//Date   	 :11��20��
//Student ID   :2019218029
//*********************************************************
#include<stdio.h>
#include<string.h>
int main(void)
{
    char str[10][80], temp[80];
    int i, j;
    printf("�������������:\n");
    for(i = 0; i < 10; i++)
    {
        gets(str[i]);
    }
    for(i = 0; i < 9; i++)
    {
        for(j = i + 1; j < 10; j++)
        {
            if(strcmp(str[i],str[j])< 0)
                {
                    strcpy(temp, str[i]);
                    strcpy(str[i], str[j]);
                    strcpy(str[j], temp);
                }
        }
    }
    printf("�����Ϊ:\n");
    for(i = 0; i < 10; i++)
    {
        puts(str[i]);
    }
    return 0;
}
