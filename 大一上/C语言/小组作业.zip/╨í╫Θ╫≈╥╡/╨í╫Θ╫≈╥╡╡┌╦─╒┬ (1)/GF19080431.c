//*********************************************************
//File name	 :GF19080431 
//Author  	 :����ƽ  
//Date   	 : 11��21�� 
//Student ID   :2019218018 
//*********************************************************
#include <stdio.h>
 
int main()
{
	int j,i=0,a[10]={0};
	char string[80];
	
	printf("�������ַ���:\n");
	
	gets(string);
	
	for(j=0;string[j]!='\0';j++)
	{
		for(i=0;i<10;i++)
			if(string[j]==i+48)
			{
				a[i]++;
				break;
			}		
	}
	
	for(i=0;i<10;i++)
		printf("�����ַ�'%d'�ĸ���=%d\n",i,a[i]);
		
	return 0;	 	
}
