//*********************************************************
//File name	 : 0408
//Author  	 : ������ 
//Date   	 : 2019.11.18
//Student ID   :2019218043
//*********************************************************
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
float xswl(int, int);
int main()
{
	float a[4][4];
	int i, j;
	float x, c, d;

	for( i = 0; i < 4; i++)
		for (j = 0; j < 4; j++)
		{
			a[i][j] = xswl(i, j);
		}

	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < i; j++)
		{
			printf("     ");
		}
		for (j = i; j < 4; j++)
		{
			printf("%.2f ", a[i][j]);
			
		}
		printf("\n");
	}
	
	system("pause");

	return 0;
}

float xswl(int m, int n)
{
	float z;
	z = (float)sqrt(m + n);
	return z;
}