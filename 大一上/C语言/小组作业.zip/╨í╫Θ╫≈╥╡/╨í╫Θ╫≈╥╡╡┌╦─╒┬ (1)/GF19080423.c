#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    int a[20] = {12,34,52,132,564,38,58,345,227,112,356,356,78,9876,545,100,150,140,85,74};
    int i,j,k,iPos;

    for(i = 0;i < 10;i++)
    {
        iPos = i;
        for(j = i + 1;j <20;j++)
        {
            if(a[iPos] < a[j])
            {
                iPos = j;
            }

        }
        if(iPos != i)
        {
            k = a[i];
            a[i] = a[iPos];
            a[iPos] = k;
        }

    }


    for(i = 0;i < 10;i++)
    {
        printf("%d\n",a[i]);
    }

    system("pause");
    return 0;
}
