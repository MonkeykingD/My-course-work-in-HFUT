#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    char str[1000];

    int i, t = 0;

    printf("����һ���ַ���");
    gets(str);

    for(i = 0;str[i] != 0;i++)
    {
        if(str[i] == ' '||str[i] == ','||str[i] == '.'||str[i] == ';')
        {
            t++;
        }

    }

    printf("The number of words:%d\n",t + 1);

    system("pause");
    return 0;
}
