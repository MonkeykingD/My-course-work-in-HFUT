//*********************************************************
//File name	 :GF19080419
//Author  	 :尚玉成
//Date   	 :11月20日
//Student ID   :2019218029
//*********************************************************
#include <stdio.h>
#include <math.h>
#include <string.h>
int main(void)
{
    char str[16];
    int i, j, sum, s;
    sum = 0;
    printf("Please input:");
    scanf("%s",str);
    s = strlen(str);
    if(str[0] == '0')
    {
        printf("");
    }
    else if(str[0] != '0')
    {
        printf("-");
    }
    for(i = 1,j = s - 2; i < s; i++,j-- )
    {
        if (str[i] == '1')
        {
            sum = sum + pow(2, j);
        }
    }
    printf("%d",sum);
    return 0;
}
