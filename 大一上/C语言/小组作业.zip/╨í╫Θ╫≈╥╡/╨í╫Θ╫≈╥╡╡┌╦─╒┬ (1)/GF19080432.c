//*********************************************************
//File name	 :GF19080432 
//Author  	 :����ƽ  
//Date   	 :11��17�� 
//Student ID   :2019218018 
//*********************************************************
#include <stdio.h>

int main()
{
	char string1[80],string2[80];
	int i,j=0,k=0,flag=0;
	
	printf("�������ַ�����Ҫ���ҵ��ִ�:\n");
	
	gets(string1);
	gets(string2);
	
	while(flag==0)
	{
		for(i=k;;i++)
		{
			if(string1[i]==string2[0])
			{
				k=i+1;
				break;
			}
		}	
		for(i;string2[j]!='\0';i++)
		{
			if(string1[i]==string2[j])
			{
				j++;
				flag=1;
			}	
			else
			{
				flag=0;
				j=0;
				break;
			} 
		}
	}
	printf("%d",k-1);

	return 0;
}
