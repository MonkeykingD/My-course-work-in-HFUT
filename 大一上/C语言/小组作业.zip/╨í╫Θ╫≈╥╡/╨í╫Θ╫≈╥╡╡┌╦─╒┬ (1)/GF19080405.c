//*********************************************************
//File name	 :GF19080405
//Author  	 :尚玉成
//Date   	 :11月20日
//Student ID   :2019218029
//*********************************************************
#include<stdio.h>
int main(void)
{
    char str[80], i, b;
    b = 0;
    gets(str);
    for(i = 0; str[i] != '\0'; i++)
    {
        b++;
        if(b % 2 == 0 && str[i] >= 'a' && str[i] <= 'z')
        {
            str[i] = str[i] - 32;
        }
    }
    puts(str);
    return 0;
}
