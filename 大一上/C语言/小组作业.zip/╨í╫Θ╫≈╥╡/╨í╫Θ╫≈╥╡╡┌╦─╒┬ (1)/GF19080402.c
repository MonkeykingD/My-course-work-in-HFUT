#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    int n[5] = {1,2,3,4,5}, i = 0, j, k,iPos;
    double a[5] = {100,98,90,84,75}, b[5] = {98,92,87,75,68};
    double A, B;

    for(i = 0;i < 5;i++)
    {
        A += a[i];
        B += b[i];
    }

    A /= 5;
    B /= 5;

    printf("����ƽ���ɼ���%.2f,��ѧƽ���ɼ���%.2f\n",A, B);

    for(i = 0;i < 5;i++)
    {
        if(a[i] < A && b[i] < B)
        {
            printf("\nѧ�ţ�%d,�����ɼ���%.2f,��ѧ�ɼ���%.2f\n",n[i],a[i],b[i]);
            i++;
        }
    }

    if(i == 0)
    {
        printf("Not Found!");
    }

    printf("\n��ѧ�ɼ��ɴ�С��\n");
    for(i = 0;i < 4;i++)
    {
        iPos = i;
        for(j = i + 1;j < 5;j++)
        {
            if(b[iPos] < b[j])
            {
                iPos = j;
            }
        }

        if(iPos != i)
        {
            k = b[i];
            b[i] = b[iPos];
            b[iPos] = k;

        }

    }

    for(i = 0;i < 5;i++)
    {
        printf("%.2f\n",b[i]);
    }


    system("pause");
    return 0;
}
