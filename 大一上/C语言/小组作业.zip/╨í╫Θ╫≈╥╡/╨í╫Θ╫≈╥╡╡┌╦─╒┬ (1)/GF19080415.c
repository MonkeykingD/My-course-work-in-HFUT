//*********************************************************
//File name	 : 0415
//Author  	 : ������ 
//Date   	 : 2019.11.20
//Student ID   :2019218043
//*********************************************************

#include<stdio.h>
#include<stdlib.h>
int maxm(int *p);
int main()
{
	int a[5][4], b[5];
	int i, j;

	for (i = 0; i < 5; i++)
	{
		for (j = 0; j < 4; j++)
		{
			scanf_s("%d", &a[i][j]);
		}
	}
	for (i = 0; i < 5; i++)
	{
		b[i] = maxm(a[i]);
		printf("b[%d] = %d\n", i, b[i]);
	}
	
	system("pause");

	return 0;

}

int maxm(int *p)
{
	int a, b = 0, i;
	a = *p;
	do
	{
		b++;
		p++;
		if (*p > a)
		{
			a = *p;
		}
	} while (b < 4);

	return a;

}