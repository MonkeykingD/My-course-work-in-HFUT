//*********************************************************
//File name	 :GF19080420 
//Author  	 :����ƽ  
//Date   	 :11��17�� 
//Student ID   :2019218018 
//*********************************************************
#include <stdio.h>

int main()
{
	unsigned short a;
	int s[16],i;
	
	printf("����������:\n");
	
	scanf("%u",&a);
	
	for(i=15;i>=0;i--)
	{
		s[i]=a%2;
		a=a/2;		
	}
	
	for(i=0;i<16;i++)
		printf("%d",s[i]);
	
	return 0;	
}
