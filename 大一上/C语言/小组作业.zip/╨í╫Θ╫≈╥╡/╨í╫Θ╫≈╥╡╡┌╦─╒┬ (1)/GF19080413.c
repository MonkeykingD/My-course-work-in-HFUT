//*********************************************************
//File name	 :GF19080413 
//Author  	 :����ƽ  
//Date   	 :11��17�� 
//Student ID   :2019218018 
//*********************************************************
#include <stdio.h>

int main()
{
	char string[80];
	int i=0,count=0,flag=0;
	
	printf("�������ַ���:\n");
	
	gets(string);
	
	for(i;string[i]!='\0';i++)
		count++;
	for(i=0;i<(count-1)/2;i++)
	{
		if(string[i]!=string[count-1-i])
		{
			printf("���ǻ���");
			flag=1;
			break; 
		}
	}
	
	if(flag==0)	
		printf("�ǻ���");
		
	return 0;	 
 } 
