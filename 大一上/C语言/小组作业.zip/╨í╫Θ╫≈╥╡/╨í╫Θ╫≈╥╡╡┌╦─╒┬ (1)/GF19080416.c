#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    int a[5][4], b[4] = {0}, i, j;


    printf("����һ���������е����飺\n");
    for(i = 0;i <5;i++)
    {
        for(j = 0;j < 4;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }

    for(i = 0;i < 5;i++)
    {
        for(j = 0;j < 4;j++)
        {
           b[j] += a[i][j];
        }
    }

    printf("ÿ�е�ƽ��ֵ��\n");
    for(i = 0;i < 4;i++)
    {
        printf("%.2f\n",b[i] / 4.0);
    }

    system("pause");
    return 0;
}
