#include<stdio.h>
#include<stdlib.h>
int main()
{
	double i, k, e, n;

	printf("������n=");
	scanf_s("%lf", &n);

	e = 1;
	k = 1;

	for (i = 1; i <= n; i++)
	{
		k = k * (1 / i);
		e = e + k;

		if (k < 1e-6)
		{
			break;
		}
	}
	printf("e = %lf\n", e);

	system("pause");

	return 0;
}