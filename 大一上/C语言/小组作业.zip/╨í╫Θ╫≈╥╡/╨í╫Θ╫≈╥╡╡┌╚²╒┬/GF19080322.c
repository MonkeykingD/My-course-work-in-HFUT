#include<stdio.h>
#include<stdlib.h>
int main()
{
	int x, y, z;

	for (x = 0; x <= 20; x++)
	{
		for (y = 0; y <= 50; y++)
		{
			for(z = 0; z <= 100; z++)
				if (5 * x + 2 * y + z == 100)
				{
					printf("5�� %-3d ����2�� %-3d ����1�� %-3d ��\n\n",x, y, z);
				}
		}
	}
	system("pause");

	return 0;
}