//*********************************************************
//File name	 : 
//Author  	 :  
//Date   	 : 
//Student ID   :
//*********************************************************
#include <stdio.h>

int main()
{
	float y=1,i;
	int n;
	
	printf("������n:");
	
	scanf("%d",&n);
	
	for(i=2;i<=n;i++)
	{
		y=y+1/(i*(i-1));
	}
	
	printf("y=%f",y);
	
	return 0;
}
