//*********************************************************
//File name	 :GF19080309
//Author  	 :  ������
//Date   	 : 2019.11.02
//Student ID   :2019218039
//*********************************************************

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main(void)
{
    double a = 0,b = 1,n = 1000,f0,f1,s,x,i,h,s1;

    h = 1.0 / n;

    x = a;
    f0 =  x * x + 2 * x + 3;

    for(i = 0;i < n;i++)
    {
        x = x + h;
        f1 = x * x + 2 * x + 3;
        s += (f0 + f1) / 2.0 * h;
        f0 = f1;


    }
    printf("�����ֽ��:%.2f\n",s);

    system("pause");
    return 0;
}
