#include <stdio.h>
#include <math.h>
int main(void)
{
    int a,s;
    for(a=73;a<=1000;a++)
    {
        if(a%73==0||a%127==0)
        {
            s+=sqrt(a);
        }
    }
    printf("%d",s);
    return 0;
}
