//*********************************************************
//File name	 : 
//Author  	 :  
//Date   	 : 
//Student ID   :
//*********************************************************
#include <stdio.h>
#include <math.h>

int main()
{
	double pi=0,t=1,n=1;
	
	do
	{
		pi=pi+t;
		n+=2;
		t=-t*((n-2)/n);
	}while(fabs(t)>1e-9);
	
	pi*=4;
	
	printf("pi=%.9lf",pi);
	
	return 0;
}
