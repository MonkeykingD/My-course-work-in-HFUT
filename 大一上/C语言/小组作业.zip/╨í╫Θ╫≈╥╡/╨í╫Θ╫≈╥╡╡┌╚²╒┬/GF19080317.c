#include <stdio.h>
#include <math.h>
int main(void)
{
    int a,i,j,s;
    j=1;
    s=0;
    for(i=1500;j<=5;i--)
    {
        for(a=2;a<=(int)sqrt((double)i);a++)
        {
            if(i%a==0)
            {
                break;
            }
        }
            if(a>(int)sqrt((double)i))
            {
                j++;
                s+=i;
                printf("%d\n",i);
            }

    }
    printf("%d",s);
    return 0;
}
