#include <stdio.h>
#include <math.h>
int main(void)
{
    int a,b,c,d,f,e;
    for(a=6;a<200;a+=2)
    {
        for(b=1;b<a/2;b++)
        {
            for(c=2;c<=(int)sqrt((double)b);c++)
            {
                if(b%c==0)
                {
                    break;
                }
            }
                if(c>(int)sqrt((double)b))
                {
                    d=a-b;
                    for(f=2;f<=(int)sqrt((double)d);f++)
                    {
                        if(d%f==0)
                        {
                            break;
                        }
                    }
                        if(f>(int)sqrt((double)d))
                        {
                            printf("%d=%d+%d\n",a,b,d);
                        }
                }
        }
    }

    return 0;
}
