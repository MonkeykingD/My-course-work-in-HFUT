//*********************************************************
//File name	 :GF19080323
//Author  	 :  ������
//Date   	 : 2019.11.02
//Student ID   :2019218039
//*********************************************************

#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    int sum = 1,i;

    for(i = 1;i < 10; i++)
    {

        sum = (sum + 1) * 2;
    }
    printf("��һ�����Ӹ�����%d\n",sum);

    system("pause");
    return 0;
}
