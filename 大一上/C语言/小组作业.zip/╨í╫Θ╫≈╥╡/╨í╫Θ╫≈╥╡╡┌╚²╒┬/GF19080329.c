#include<stdio.h>
#include<stdlib.h>
int main()
{
	int a, b, c, d, e, f, flag;
	flag = 0;

	for (a = 0; a <= 1; a++)
	{
		for (b = 0; b <= 1; b++)
		{
			for (c = 0; c <= 1; c++)
			{
				for (d = 0; d <= 1; d++)
				{
					for (e = 0; e <= 1; e++)
					{
						for (f = 0; f <= 1; f++)
						{
							if (a + b >= 1&&a + e + f >= 2&&a + d <= 1&&b == c&&c + d == 1&&d >= e)
							{
								flag = 1;
								break;
							}
							if (flag == 1)
								break;
						}
						if (flag == 1)
							break;
					}
					if (flag == 1)
						break;
				}
				if (flag == 1)
					break;
			}
			if (flag == 1)
				break;
		}
		if (flag == 1)
			break;
	}
	if (a == 1)
		printf("A��");
	if (b == 1)
		printf("B��");
	if (c == 1)
		printf("C��");
	if (d == 1)
		printf("D��");
	if (e == 1)
		printf("E��");
	if (f == 1)
		printf("F��");
	printf("��������.\n");

	system("pause");
	return 0;
}