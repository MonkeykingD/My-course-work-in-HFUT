#include <stdio.h>
int main(void)
{
    int a,b,c,d,e,f;
    for(a=1000;a<=9999;a++)
    {
        b=a/1000;
        c=a%1000/100;
        d=a%100/10;
        e=a%10;
        f=e*1000+d*100+c*10+b;
        if(f%a==0)
        {
            printf("%d\n",a);
        }
    }
    return 0;
}
