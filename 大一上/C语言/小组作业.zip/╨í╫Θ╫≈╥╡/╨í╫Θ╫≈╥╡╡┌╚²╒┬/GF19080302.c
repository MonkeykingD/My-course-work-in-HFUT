//*********************************************************
//File name	 :GF19080302
//Author  	 : 刘冠良
//Date   	 : 2019.11.02
//Student ID   :2019218039
//*********************************************************
#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    int a,i,t,sum;

    for(a = 1;a < 1000;a++ )
    {
        sum = 0;

        for(i = 1;i < a;i++)
        {
            t = a % i;
            if(t == 0)
            {
                sum += i;
            }
        }

        if(sum == a)
        {
            printf("%d\n",a);
        }



    }

    system("pause");
    return 0;
}
