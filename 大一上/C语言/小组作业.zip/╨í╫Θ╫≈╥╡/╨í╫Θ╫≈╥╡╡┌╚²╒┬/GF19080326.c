#include<stdio.h>
int main(void)
{
    int a;
    for (a = 1000; a < 2020; a++)
    {
        if(a % 4 == 0 && a % 100 != 0 || a % 400 == 0)
        {
            printf("%5d",a);
        }
    }
    return 0;
}
