#include<stdio.h>
#include<stdlib.h>
int main()
{
	int a, b, c;
	
	for (a = 0; a <= 9; a++)
	{
		for (c = 0; c <= 72; c += 2)
		{
			b = 36 - a - c;
			if (a + b + c == 36 && 4 * a + 2 * b + c / 2 == 36)
				{
					printf("����=%d,Ů��=%d,С��=%d\n", a, b, c);
				}
		}
	} 
	system("pause");

	return 0;
}