#include<stdio.h>
int main(void)
{
    int m, n, x, t;
    printf("Please input two number");
    scanf("%d%d",&m, &n);
    if ( n > m)
    {
        t = n;
        n = m;
        m = t;
    }
    while(1)
    {
        x = m % n;
        if ( x == 0)
            break;
        else
        {
            m = n;
            n = x;
        }
    }
    printf("%d��%d�����Լ����%d",m, n, n);
    return 0;
}
