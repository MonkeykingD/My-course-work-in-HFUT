#include<stdio.h>
int main(void)
{
    int n;
    float sum, x, a, b, c;
    sum = 0.;
    a = 1.;
    b = 2.;
    c = 2.;
    for(n = 0 ; n < 30; n++)
    {
        x = b / a;
        sum = sum + x;
        b = a + b;
        a = c;
        c = b;
    }
    printf("%f",sum);
    return 0;
}
