#include<Stdio.h>
#include<stdlib.h>
#include<math.h>
int main()                          //��f(x)=x^4- 2x^3 -4x^2 + 4x +6 ��1.0�����ĸ�

{
	double x, x0, f, f1;
	x = 1.;
	do 
	{
		x0 = x;
		f = (((x0 - 2.) * x0 - 4.) * x0 + 4.) * x0 + 6.;
		f1 = ((4. * x0 - 6.) * x0 - 8.) * x0 + 4.;
		x = x0 - f / f1;
	} while (fabs(x - x0) > 1e-10);

	printf("��1.0�����ĸ�x = %.3lf\n", x);

	system("pause");

	return 0;

}