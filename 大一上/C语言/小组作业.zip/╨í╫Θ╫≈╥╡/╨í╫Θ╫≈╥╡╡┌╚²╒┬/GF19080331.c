#include <stdio.h>
#include <math.h>
int main(void)
{
    int i,j,a,b,c,d;
    for(i=2;i<20;i++)
    {
        for(j=2;j<=(int)sqrt((double)i);j++)
        {
            if(i%j==0)
            {
                break;
            }
        }
        if(j>(int)sqrt((double)i))
        {
            for(a=1,b=i;b>0;b--)
            {
                a*=2;
            }
            c=a-1;
            for(d=2;d<=(int)sqrt((double)c);d++)
            {
                if(c%d==0)
                {
                    break;
                }
            }
            if(d>(int)sqrt((double)c))
            {
                printf("%d\n",i);
            }
        }
    }

    return 0;
}
