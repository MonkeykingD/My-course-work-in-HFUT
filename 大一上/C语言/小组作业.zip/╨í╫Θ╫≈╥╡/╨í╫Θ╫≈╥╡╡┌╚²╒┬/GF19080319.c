#include<stdio.h>
int main(void)
{
    int a[4], i, q;
    printf("Input a 4 digits number\n");
    scanf("%d",&a[i]);
    for (i = 0; i < 4; i++)
    {

        q = (i + 5 * i) % 10;
        printf("%d", a[q]);
    }
    return 0;
}
