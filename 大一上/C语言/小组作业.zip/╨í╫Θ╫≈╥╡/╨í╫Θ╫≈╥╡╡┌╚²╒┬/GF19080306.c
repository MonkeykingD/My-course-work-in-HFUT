//*********************************************************
//File name	 : 
//Author  	 :  
//Date   	 : 
//Student ID   :
//*********************************************************
#include <stdio.h>
#include <math.h>

int main()
{
	double cosx=0,i=1,x,n=0;
	
	printf("������x:");
	
	scanf("%lf",&x);
	
	do
	{
		cosx=cosx+i;
		n+=2;
		i=-i*x*x/(n*(n-1));
	}while(fabs(i)>=1e-6);
	
	printf("cosx=%lf",cosx);
	
	return 0;
 } 
